
# TODO: remove in Rake 11
