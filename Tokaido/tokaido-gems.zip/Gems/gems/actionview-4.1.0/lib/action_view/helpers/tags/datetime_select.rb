module ActionView
  module Helpers
    module Tags # :nodoc:
      class DatetimeSelect < DateSelect # :nodoc:
      end
    end
  end
end
