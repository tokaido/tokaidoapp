module ActionView
  module Helpers
    module Tags # :nodoc:
      class TelField < TextField # :nodoc:
      end
    end
  end
end
