require 'cuba'
require 'cuba/render'

require 'tokaido/cubalog/app'
