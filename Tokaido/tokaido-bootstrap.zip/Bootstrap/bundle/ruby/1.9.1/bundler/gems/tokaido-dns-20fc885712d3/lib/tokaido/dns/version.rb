module Tokaido
  module DNS
    VERSION = "0.5.0"
  end
end
