module SimpleCov
  module Formatter
    class HTMLFormatter
      VERSION = "0.7.1"
    end
  end
end