require 'rubygems'
require 'bundler/setup'
require 'simplecov'
require 'simplecov-html'

require 'test/unit'

class Test::Unit::TestCase
end
