puts "foo"
puts "foo"
puts "foo"
puts "foo"
