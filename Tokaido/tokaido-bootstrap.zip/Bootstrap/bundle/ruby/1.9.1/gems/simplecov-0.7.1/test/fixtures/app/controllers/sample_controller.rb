# Foo class
class Foo
  def initialize
    @foo = 'baz'
  end

  def bar
    @foo
  end
end
