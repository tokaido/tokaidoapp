module SimpleCov
  VERSION = "0.7.1"
end