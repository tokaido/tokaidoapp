module MultiJson
  VERSION = '1.7.2' unless defined?(MultiJson::VERSION)
end
