# For backward compatibility with rspec-1
require 'rspec/mocks'

RSpec::Mocks.warn_deprecation "\nDEPRECATION: `require 'spec/mocks' " +
 " is deprecated. Please require 'rspec/mocks' instead."

