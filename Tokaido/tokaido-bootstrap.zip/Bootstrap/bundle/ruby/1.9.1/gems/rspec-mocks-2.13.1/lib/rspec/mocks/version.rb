module RSpec
  module Mocks
    module Version
      STRING = '2.13.1'
    end
  end
end
