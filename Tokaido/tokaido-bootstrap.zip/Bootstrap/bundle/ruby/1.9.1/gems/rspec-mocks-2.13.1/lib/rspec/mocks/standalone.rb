require 'rspec/mocks'

RSpec::Mocks.setup(self)
