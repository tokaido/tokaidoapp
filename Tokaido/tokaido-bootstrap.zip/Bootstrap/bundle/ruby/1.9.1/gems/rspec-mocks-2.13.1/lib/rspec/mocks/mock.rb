module RSpec
  module Mocks
    class Mock
      include TestDouble
    end
  end
end
