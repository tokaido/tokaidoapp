module RSpec
  module Expectations
    # @private
    module Version
      STRING = '2.13.0'
    end
  end
end
