module RSpec # :nodoc:
  module Version # :nodoc:
    STRING = '2.13.0'
  end
end
