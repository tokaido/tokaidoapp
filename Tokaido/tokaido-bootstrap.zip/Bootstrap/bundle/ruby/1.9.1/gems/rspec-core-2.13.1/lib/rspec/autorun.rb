require 'rspec/core'
RSpec::Core::Runner.autorun
