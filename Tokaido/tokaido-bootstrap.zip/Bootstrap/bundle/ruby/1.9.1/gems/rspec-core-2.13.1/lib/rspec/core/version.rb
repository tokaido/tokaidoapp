module RSpec
  module Core
    module Version
      STRING = '2.13.1'
    end
  end
end
