Autotest.add_discovery { "rspec2" } if File.exist?("./.rspec")
