module Tokaido
  module Bootstrap
    VERSION = "0.5.0"
  end
end
